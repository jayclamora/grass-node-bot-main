/**
 * Accounts list file
 * write your accounts like this
 * EMAILPASSWORD ACCOUNTYPE
 * export const accounts = {
 *     email: "YOUR EMAIL",
 *     password: "YOUR PASSWORD",
 * };
 *
 * USERID ACCOUNTTYPE
 * export const accounts = "YOURUSERID"
 */
export const accounts = {
  email: "YOUR EMAIL",
  password: "YOUR PASSWORD",
};
